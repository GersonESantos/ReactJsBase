import Menu from "@/components/Menu";
import Footer from "@/components/Footer";

const Contact = () => {
    return (
        <div>
            <Menu /><br />
            <h2>Contato</h2><br />
            <Footer />
        </div>
    );
}

export default Contact;

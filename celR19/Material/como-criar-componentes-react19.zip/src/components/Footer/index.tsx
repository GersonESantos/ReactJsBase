const Footer = () => {
    return(
        <footer>
            <p>&copy; { new Date().getFullYear() } Celke. Todos os direitos reservados</p>
        </footer>
    )
}

export default Footer;